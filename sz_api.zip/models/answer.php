<?php

class Answer {
    private $conn;
    private $table = "answers";

    public $id;
    public $applicant_id;
    public $question_id;
    public $answer;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table . " (applicant_id, question_id, answer)
                  VALUES (:applicant_id, :question_id, :answer)";
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':applicant_id', $this->applicant_id);
        $stmt->bindParam(':question_id', $this->question_id);
        $stmt->bindParam(':answer', $this->answer);

        return $stmt->execute();
    }

    public function getByApplicant($applicant_id) {
        $query = "SELECT * FROM " . $this->table . " WHERE applicant_id = :applicant_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':applicant_id', $applicant_id);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>
