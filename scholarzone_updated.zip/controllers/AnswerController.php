<?php

require_once 'models/answer.php';
require_once 'models/applicant.php';

class AnswerController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function submitAnswer($data, $token) {
        $applicant = (new Applicant($this->db))->getByToken($token);

        if (!$applicant) {
            return [
                "status" => 401,
                "message" => "Unauthorized: Invalid token."
            ];
        }

        if (!isset($data['question_id'])) {
            return [
                "status" => 400,
                "message" => "Missing required field: question_id."
            ];
        }

        $answer = new Answer($this->db);
        $answer->applicant_id = $applicant['id'];
        $answer->question_id = $data['question_id'];

        $questionType = $answer->getQuestionType($data['question_id']);

        if ($questionType == 'upload') {
            if (!isset($_FILES['answer'])) {
                return [
                    "status" => 400,
                    "message" => "Missing required field: file."
                ];
            }
            $answer->file = $_FILES['answer'];
        } else {
            if (!isset($data['answer'])) {
                return [
                    "status" => 400,
                    "message" => "Missing required field: answer."
                ];
            }
            $answer->answer = $data['answer'];
        }

        $result = $answer->create();
        if ($result['status'] == 'success') {
            return [
                "status" => 201,
                "message" => $result['message']
            ];
        } else {
            return [
                "status" => 400,
                "message" => $result['message']
            ];
        }
    }
}

?>