<?php

class Answer {
    private $conn;
    private $table = "answers";

    public $id;
    public $applicant_id;
    public $question_id;
    public $answer;
    public $file;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        if (!$this->questionExists($this->question_id)) {
            return ['status' => 'error', 'message' => 'Invalid question_id.'];
        }

        $questionType = $this->getQuestionType($this->question_id);

        if ($questionType == 'upload') {
            $uploadResult = $this->uploadFile();
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $this->answer = $uploadResult['file_path'];
        }

        $query = "INSERT INTO " . $this->table . " (applicant_id, question_id, answer)
                  VALUES (:applicant_id, :question_id, :answer)";
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':applicant_id', $this->applicant_id, PDO::PARAM_INT);
        $stmt->bindParam(':question_id', $this->question_id, PDO::PARAM_INT);
        $stmt->bindParam(':answer', $this->answer, PDO::PARAM_STR);

        if ($stmt->execute()) {
            return ['status' => 'success', 'message' => 'Answer submitted successfully.'];
        } else {
            return ['status' => 'error', 'message' => 'Failed to submit answer.'];
        }
    }

    private function questionExists($question_id) {
        $query = "SELECT COUNT(*) FROM questions WHERE id = :question_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    function getQuestionType($question_id) {
        $query = "SELECT type FROM questions WHERE id = :question_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['type'] ?? 'question';
    }

    private function uploadFile() {
        $targetDir = "documents/";
        $fileName = str_replace(' ', '_', basename($this->file["name"]));
        $uniqueFileName = uniqid() . '_' . $fileName;
        $targetFile = $targetDir . $uniqueFileName;
        $uploadOk = 1;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        if ($this->file["size"] > 5000000) { 
            return ['status' => 'error', 'message' => 'Sorry, your file is too large.'];
        }

        $allowedTypes = ['jpg', 'png', 'jpeg', 'gif', 'pdf', 'doc', 'docx'];
        if (!in_array($fileType, $allowedTypes)) {
            return ['status' => 'error', 'message' => 'Sorry, only JPG, JPEG, PNG, GIF, PDF, DOC, and DOCX files are allowed.'];
        }

        if ($uploadOk == 0) {
            return ['status' => 'error', 'message' => 'Sorry, your file was not uploaded.'];
        } else {
            if (move_uploaded_file($this->file["tmp_name"], $targetFile)) {
                $baseUrl = 'https://active-fox-exactly.ngrok-free.app' . '/ScholarZone/';
                $fileUrl = $baseUrl . $targetFile;
                return ['status' => 'success', 'file_path' => $fileUrl];
            } else {
                return ['status' => 'error', 'message' => 'Sorry, there was an error uploading your file.'];
            }
        }
    }

    public function getByApplicant($applicant_id) {
        $query = "SELECT * FROM " . $this->table . " WHERE applicant_id = :applicant_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':applicant_id', $applicant_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>