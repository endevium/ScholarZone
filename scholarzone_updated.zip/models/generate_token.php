<?php
function generateAccessToken() {
    $keyFilePath = "./scholarzone-d300c-42bf3a22d8e3.json"; // Path to service account JSON file
    $serviceAccount = json_decode(file_get_contents($keyFilePath), true);

    $privateKey = $serviceAccount['private_key'];
    $clientEmail = $serviceAccount['client_email'];
    $tokenUri = "https://oauth2.googleapis.com/token";

    $now = time();
    $jwtHeader = json_encode(["alg" => "RS256", "typ" => "JWT"]);
    $jwtClaim = json_encode([
        "iss" => $clientEmail,
        "scope" => "https://www.googleapis.com/auth/firebase.messaging",
        "aud" => $tokenUri,
        "exp" => $now + 3600,
        "iat" => $now
    ]);

    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($jwtHeader));
    $base64UrlClaim = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($jwtClaim));

    $signatureInput = $base64UrlHeader . "." . $base64UrlClaim;
    openssl_sign($signatureInput, $signature, $privateKey, "SHA256");
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    $jwt = $signatureInput . "." . $base64UrlSignature;

    $postData = http_build_query([
        "grant_type" => "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion" => $jwt
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenUri);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/x-www-form-urlencoded"]);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    return $data["access_token"] ?? null;
}

?>
