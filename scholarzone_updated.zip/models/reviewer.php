<?php

require_once 'models/generate_token.php';

class Reviewer {
    private $conn;
    private $table = "reviewers";

    public $id;
    public $username;
    public $email;
    public $password;
    public $firstname;
    public $lastname;
    public $gender;
    public $birthdate;
    public $phone_number;
    public $company;
    public $rpc;
    public $bsb;
    public $company_id;
    public $certificate;
    public $authorization;

    public function __construct($db) {
        $this->conn = $db;
    }

    private function emailExists($email) {
        $query = "SELECT id FROM " . $this->table . " WHERE email = :email LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    public function create() {
        if ($this->emailExists($this->email)) {
            return ['status' => 'error', 'message' => 'Email already exists.'];
        }

        if ($this->company_id) {
            $uploadResult = $this->uploadFile($this->company_id);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $this->company_id = $uploadResult['file_path'];
        }

        if ($this->certificate) {
            $uploadResult = $this->uploadFile($this->certificate);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $this->certificate = $uploadResult['file_path'];
        }

        if ($this->authorization) {
            $uploadResult = $this->uploadFile($this->authorization);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $this->authorization = $uploadResult['file_path'];
        }

        $query = "INSERT INTO " . $this->table . " 
            (username, email, password, firstname, lastname, gender, birthdate, phone_number, company, rpc, bsb, company_id, certificate, authorization)
            VALUES (:username, :email, :password, :firstname, :lastname, :gender, :birthdate, :phone_number, :company, :rpc, :bsb, :company_id, :certificate, :authorization)";
        
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password', $this->password);
        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':birthdate', $this->birthdate);
        $stmt->bindParam(':phone_number', $this->phone_number);     
        $stmt->bindParam(':company', $this->company);                    
        $stmt->bindParam(':rpc', $this->rpc);
        $stmt->bindParam(':bsb', $this->bsb);
        $stmt->bindParam(':company_id', $this->company_id);
        $stmt->bindParam(':certificate', $this->certificate);
        $stmt->bindParam(':authorization', $this->authorization);

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            $this->sendFCMNotificationToAdmin("New reviewer registration: " . $this->username);
            return ['status' => 'success', 'message' => 'Reviewer account created successfully.'];
        }
        return ['status' => 'error', 'message' => 'Failed to create reviewer account.'];
    }

    public function getDashboardData($reviewer_id) {
        $data = [];
    
        $query = "SELECT COUNT(*) AS total_applications 
                  FROM scholarship_applications 
                  WHERE reviewer_id = :reviewer_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewer_id, PDO::PARAM_INT);
        $stmt->execute();
        $data['total_scholarship_applications'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_applications'];

        $query = "SELECT COUNT(*) AS pending_reviews 
                  FROM applications 
                  WHERE scholarship_application_id IN (
                      SELECT id FROM scholarship_applications WHERE reviewer_id = :reviewer_id
                  ) AND status = 'pending'";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewer_id, PDO::PARAM_INT);
        $stmt->execute();
        $data['pending_reviews'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_reviews'];

        $query = "SELECT COUNT(DISTINCT applicant_id) AS total_respondents 
                  FROM applications 
                  WHERE scholarship_application_id IN (
                      SELECT id FROM scholarship_applications WHERE reviewer_id = :reviewer_id
                  )";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewer_id, PDO::PARAM_INT);
        $stmt->execute();
        $data['total_respondents'] = $stmt->fetch(PDO::FETCH_ASSOC)['total_respondents'];
    
        return $data;
    }
    
    public function getApplicationsReviewedOverTime($reviewer_id) {
        $query = "SELECT DATE(updated_at) AS review_date, COUNT(*) AS total_reviewed 
                  FROM applications 
                  WHERE scholarship_application_id IN (
                      SELECT id FROM scholarship_applications WHERE reviewer_id = :reviewer_id
                  )
                  GROUP BY DATE(review_date) 
                  ORDER BY review_date ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewer_id, PDO::PARAM_INT);
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function update($id, $fields) {
        if (isset($fields['company_id'])) {
            $uploadResult = $this->uploadFile($fields['company_id']);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $fields['company_id'] = $uploadResult['file_path'];
        }

        if (isset($fields['certificate'])) {
            $uploadResult = $this->uploadFile($fields['certificate']);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $fields['certificate'] = $uploadResult['file_path'];
        }

        if (isset($fields['authorization'])) {
            $uploadResult = $this->uploadFile($fields['authorization']);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $fields['authorization'] = $uploadResult['file_path'];
        }

        $setClause = [];
        foreach ($fields as $key => $value) {
            $setClause[] = "$key = :$key";
        }

        $query = "UPDATE " . $this->table . " SET " . implode(", ", $setClause) . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);

        foreach ($fields as $key => $value) {
            $stmt->bindValue(":$key", htmlspecialchars(strip_tags($value)));
        }

        return $stmt->execute();
    }

    private function uploadFile($file) {
        $targetDir = "documents/";
        $fileName = str_replace(' ', '_', basename($file["name"]));
        $uniqueFileName = uniqid() . '_' . $fileName;
        $targetFile = $targetDir . $uniqueFileName;
        $uploadOk = 1;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        if (file_exists($targetFile)) {
            return ['status' => 'error', 'message' => 'Sorry, file already exists.'];
        }

        if ($file["size"] > 5000000) { 
            return ['status' => 'error', 'message' => 'Sorry, your file is too large.'];
        }

        $allowedTypes = ['jpg', 'png', 'jpeg', 'gif', 'pdf', 'doc', 'docx'];
        if (!in_array($fileType, $allowedTypes)) {
            return ['status' => 'error', 'message' => 'Sorry, only JPG, JPEG, PNG, GIF, PDF, DOC, and DOCX files are allowed.'];
        }

        if ($uploadOk == 0) {
            return ['status' => 'error', 'message' => 'Sorry, your file was not uploaded.'];
        } else {
            if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                $baseUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/ScholarZone/';
                $fileUrl = $baseUrl . $targetFile;
                return ['status' => 'success', 'file_path' => $fileUrl];
            } else {
                return ['status' => 'error', 'message' => 'Sorry, there was an error uploading your file.'];
            }
        }
    }

    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getByToken($token) {
        $query = "SELECT a.* FROM " . $this->table . " a 
                  JOIN reviewer_tokens t ON a.id = t.reviewer_id 
                  WHERE t.token = :token";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $token);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function sendFCMNotificationToAdmin($message) {
        $fcm_token = "ejNOUTMipntu7rG4AT6Pxx:APA91bHt3UnxszyfZ6E9b2KuYi_A6N81GbyzoSJCbXskjTe9et1IB3y01pKWAypXX_DbKMaAKT2AiI8ZyQDOXmh46B9_FPiwpH0TGsif37iaMMt4sjmnQZc";

        if (empty($fcm_token)) {
            return "Error: FCM token is missing.";
        }

        $accessToken = generateAccessToken();

        if (!$accessToken) {
            return "Error: Failed to generate access token.";
        }

        $url = "https://fcm.googleapis.com/v1/projects/scholarzone-d300c/messages:send";
        
        $headers = [
            "Authorization: Bearer " . $accessToken,
            "Content-Type: application/json"
        ];

        $notification = [
            "message" => [
                "token" => $fcm_token,
                "notification" => [
                    "title" => "New Reviewer Registration",
                    "body" => $message
                ],
                "data" => [
                    "reviewer_id" => (string) $this->id,
                    "status" => "pending"
                ]
            ]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return "cURL Error: " . $curlError;
        }

        $this->storeNotification("New Reviewer Registration", $message);

        return "HTTP Code: $httpCode\nResponse: $response";
    }

    public function getReviewerNotifications($reviewerId) {
        $query = "SELECT * FROM reviewer_notifications WHERE reviewer_id = :reviewer_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewerId);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function storeNotification($title, $body) {
        $query = "INSERT INTO admin_notifications (title, body) VALUES (:title, :body)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(":title", $title, PDO::PARAM_STR);
        $stmt->bindValue(":body", $body, PDO::PARAM_STR);
        $stmt->execute();
    }
}

?>