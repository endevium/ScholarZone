<?php

class Admin {
    private $db;
    private $table = "admin";

    public $id;
    public $email;
    public $password;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getByEmail($email) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function storeToken($adminId, $token) {
        $query = "INSERT INTO admin_tokens (admin_id, token) VALUES (:admin_id, :token)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function create($email, $password) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $query = "INSERT INTO " . $this->table . " (email, password) VALUES (:email, :password)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':password', $hashed_password, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function getDashboardData() {
        $data = [];
    
        $query = "SELECT COUNT(*) AS pending_applications 
                  FROM scholarship_applications 
                  WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $data['pending_applications'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_applications'];

        $query = "SELECT COUNT(*) AS pending_reviewers 
                  FROM reviewers 
                  WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $data['pending_reviewers'] = $stmt->fetch(PDO::FETCH_ASSOC)['pending_reviewers'];

        $query = "SELECT COUNT(*) AS total_applicants FROM applicants";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $total_applicants = $stmt->fetch(PDO::FETCH_ASSOC)['total_applicants'];

        $query = "SELECT COUNT(*) AS total_reviewers FROM reviewers";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $total_reviewers = $stmt->fetch(PDO::FETCH_ASSOC)['total_reviewers'];

        $data['total_users'] = $total_applicants + $total_reviewers;
    
        return $data;
    }
    
    public function getMonthlyReviewerSignUps() {
        $query = "SELECT DATE_FORMAT(created_at, '%M %Y') AS month, COUNT(*) AS total_signups 
                  FROM reviewers 
                  GROUP BY month 
                  ORDER BY month ASC";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function verifyReviewer($reviewerId) {
        $query = "UPDATE reviewers SET is_verified = 'yes' WHERE id = :reviewer_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewerId, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $this->sendFCMNotificationToReviewer($reviewerId, "Verification", "Your account has been verified.");
            return ['status' => 'success', 'message' => 'Reviewer verified successfully.'];
        }
        return ['status' => 'error', 'message' => 'Failed to verify reviewer.'];
    }
    
    public function verifyScholarship($scholarshipId) {
        $query = "UPDATE scholarship_applications SET is_verified = 'yes' WHERE id = :scholarship_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':scholarship_id', $scholarshipId, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $query = "SELECT reviewer_id FROM scholarship_applications WHERE id = :scholarship_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':scholarship_id', $scholarshipId, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $reviewerId = $result['reviewer_id'];

            $this->sendFCMNotificationToReviewer($reviewerId, "Scholarship Verification", "Your scholarship has been verified.");
            return ['status' => 'success', 'message' => 'Scholarship verified successfully.'];
        }
        return ['status' => 'error', 'message' => 'Failed to verify scholarship.'];
    }
    
    public function getUnverifiedReviewers() {
        $query = "SELECT * FROM reviewers WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUnverifiedScholarships() {
        $query = "SELECT * FROM scholarship_applications WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function sendFCMNotificationToReviewer($reviewerId, $title, $message) {
        $fcm_token = "ejNOUTMipntu7rG4AT6Pxx:APA91bHt3UnxszyfZ6E9b2KuYi_A6N81GbyzoSJCbXskjTe9et1IB3y01pKWAypXX_DbKMaAKT2AiI8ZyQDOXmh46B9_FPiwpH0TGsif37iaMMt4sjmnQZc";

        if (empty($fcm_token)) {
            return "Error: FCM token is missing.";
        }

        $accessToken = generateAccessToken();

        if (!$accessToken) {
            return "Error: Failed to generate access token.";
        }

        $url = "https://fcm.googleapis.com/v1/projects/scholarzone-d300c/messages:send";
        
        $headers = [
            "Authorization: Bearer " . $accessToken,
            "Content-Type: application/json"
        ];

        $notification = [
            "message" => [
                "token" => $fcm_token,
                "notification" => [
                    "title" => $title,
                    "body" => $message
                ],
                "data" => [
                    "reviewer_id" => (string) $reviewerId,
                    "status" => "pending"
                ]
            ]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return "cURL Error: " . $curlError;
        }

        $this->storeNotification($reviewerId, $title, $message);

        return "HTTP Code: $httpCode\nResponse: $response";
    }

    public function getNotifications() {
        $query = "SELECT * FROM admin_notifications";
        $stmt = $this->db->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function storeNotification($reviewerId, $title, $body) {
        $query = "SELECT id FROM reviewers WHERE id = :reviewer_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewerId, PDO::PARAM_INT);
        $stmt->execute();
        $reviewer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reviewer) {
            $query = "INSERT INTO reviewer_notifications (reviewer_id, title, body) VALUES (:reviewer_id, :title, :body)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':reviewer_id', $reviewerId, PDO::PARAM_INT);
            $stmt->bindValue(":title", $title, PDO::PARAM_STR);
            $stmt->bindValue(":body", $body, PDO::PARAM_STR);
            $stmt->execute();
        } else {
            throw new Exception("Reviewer ID does not exist.");
        }
    }
}
?>