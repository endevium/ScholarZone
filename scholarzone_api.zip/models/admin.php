<?php

class Admin {
    private $db;
    private $table = "admin";

    public $id;
    public $email;
    public $password;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getByEmail($email) {
        $query = "SELECT * FROM " . $this->table . " WHERE email = :email LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function storeToken($adminId, $token) {
        $query = "INSERT INTO admin_tokens (admin_id, token) VALUES (:admin_id, :token)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':admin_id', $adminId, PDO::PARAM_INT);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->execute();
    }

    public function create($email, $password) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $query = "INSERT INTO " . $this->table . " (email, password) VALUES (:email, :password)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':password', $hashed_password, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function verifyReviewer($reviewerId) {
        $query = "UPDATE reviewers SET is_verified = 'yes' WHERE id = :reviewer_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewerId, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    public function verifyScholarship($scholarshipId) {
        $query = "UPDATE scholarship_applications SET is_verified = 'yes' WHERE id = :scholarship_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':scholarship_id', $scholarshipId, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    public function getUnverifiedReviewers() {
        $query = "SELECT * FROM reviewers WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUnverifiedScholarships() {
        $query = "SELECT * FROM scholarship_applications WHERE is_verified = 'no'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}
?>