<?php

require_once 'models/answer.php';
require_once 'models/applicant.php';

class AnswerController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function submitAnswer($data, $token) {
        $applicant = (new Applicant($this->db))->getByToken($token);

        if (!$applicant) {
            return [
                "status" => 401,
                "message" => "Unauthorized: Invalid token."
            ];
        }

        if (!isset($data['question_id'], $data['answer'])) {
            return [
                "status" => 400,
                "message" => "Missing required fields: question_id and answer."
            ];
        }

        $answer = new Answer($this->db);
        $answer->applicant_id = $applicant['id'];
        $answer->question_id = $data['question_id'];
        $answer->answer = $data['answer'];

        if ($answer->create()) {
            return [
                "status" => 201,
                "message" => "Answer submitted successfully."
            ];
        } else {
            return [
                "status" => 400,
                "message" => "Failed to submit answer."
            ];
        }
    }
}

?>