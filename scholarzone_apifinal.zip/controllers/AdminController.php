<?php

require_once 'models/admin.php';

class AdminController {
    private $admin;

    public function __construct($db) {
        $this->admin = new Admin($db);
    }

    public function login($email, $password) {
        $admin = $this->admin->getByEmail($email);

        if (!$admin) {
            return [
                "status" => 404,
                "message" => "Admin not found."
            ];
        }

        if (!password_verify($password, $admin['password'])) {
            return [
                "status" => 401,
                "message" => "Invalid email or password."
            ];
        }

        $token = bin2hex(random_bytes(32));
        $this->admin->storeToken($admin['id'], $token);

        return [
            "status" => 200,
            "message" => "Login successful.",
            "id" => $admin['id'],
            "token" => $token
        ];
    }

    public function createAdmin($email, $password) {
        if ($this->admin->create($email, $password)) {
            return [
                "status" => 201,
                "message" => "Admin created successfully."
            ];
        } else {
            return [
                "status" => 500,
                "message" => "Failed to create admin."
            ];
        }
    }

    public function getUnverifiedReviewers() {
        return $this->admin->getUnverifiedReviewers();
    }

    public function verifyReviewer($reviewerId) {
        if ($this->admin->verifyReviewer($reviewerId)) {
            return [
                "status" => 200,
                "message" => "Reviewer verified successfully."
            ];
        } else {
            return [
                "status" => 500,
                "message" => "Failed to verify reviewer."
            ];
        }
    }

    public function rejectReviewer($reviewerId) {
        if ($this->admin->rejectReviewer($reviewerId)) {
            return [
                "status" => 200,
                "message" => "Reviewer rejected successfully."
            ];
        } else {
            return [
                "status" => 500,
                "message" => "Failed to reject reviewer."
            ];
        }
    }

    public function getUnverifiedScholarships() {
        return $this->admin->getUnverifiedScholarships();
    }

    public function verifyScholarship($scholarshipId) {
        if ($this->admin->verifyScholarship($scholarshipId)) {
            return [
                "status" => 200,
                "message" => "Scholarship verified successfully."
            ];
        } else {
            return [
                "status" => 500,
                "message" => "Failed to verify scholarship."
            ];
        }
    }

    public function rejectScholarship($scholarshipId) {
        if ($this->admin->rejectScholarship($scholarshipId)) {
            return [
                "status" => 200,
                "message" => "Scholarship rejected successfully."
            ];
        } else {
            return [
                "status" => 500,
                "message" => "Failed to reject scholarship."
            ];
        }
    }

    public function getNotifications(): array {
        $notifications = $this->admin->getNotifications();
        
        if ($notifications) {
            return [
                "data" => $notifications
            ];
        } else {
            return [
                "status" => 404,
                "message" => "No notifications found."
            ];
        }
    }

    public function getDashboardData(): array {
        $data = $this->admin->getDashboardData();

        if ($data) {
            return [
                "status" => 200,
                "data" => $data
            ];
        } else {
            return [
                "status" => 404,
                "message" => "No dashboard data found."
            ];
        }
    }

    public function getMonthlyReviewerSignUps(): array {
        $data = $this->admin->getMonthlyReviewerSignUps();

        if ($data) {
            return [
                "status" => 200,
                "data" => $data
            ];
        } else {
            return [
                "status" => 404,
                "message" => "No data found."
            ];
        }
    }
}
?>