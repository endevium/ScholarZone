<?php

class ScholarshipApplication {
    private $db;
    private $table = "scholarship_applications";

    public $id;
    public $reviewer_id;
    public $application_name;
    public $company;
    public $application_description;
    public $duration;
    public $application_image;
    public $category;
    public $slots;
    public $taken_slots;
    public $deadline;

    public function __construct($db) {
        $this->db = $db;
    }

    public function create() {
        if ($this->application_image) {
            $uploadResult = $this->uploadFile($this->application_image);
            if ($uploadResult['status'] == 'error') {
                return $uploadResult;
            }
            $this->application_image = $uploadResult['file_path'];
        }

        $query = "INSERT INTO " . $this->table . " (reviewer_id, application_name, company, application_description, duration, application_image, category, slots, deadline)
                  VALUES (:reviewer_id, :application_name, :company, :application_description, :duration, :application_image, :category, :slots, :deadline)";
        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':reviewer_id', $this->reviewer_id);
        $stmt->bindParam(':application_name', $this->application_name);
        $stmt->bindParam(':company', $this->company);
        $stmt->bindParam(':application_description', $this->application_description);
        $stmt->bindParam(':duration', $this->duration);
        $stmt->bindParam(':application_image', $this->application_image);
        $stmt->bindParam(':category', $this->category);
        $stmt->bindParam(':slots', $this->slots);
        $stmt->bindParam(':deadline', $this->deadline);

        if ($stmt->execute()) {
            $this->id = $this->db->lastInsertId();
            $this->sendFCMNotificationToAdmin("New Scholarship Application: " . $this->application_name);
            return ['status' => 'success', 'message' => 'Scholarship application created successfully.'];
        }
        return ['status' => 'error', 'message' => 'Failed to create scholarship application.'];
    }

    public function update() {
        $query = "UPDATE " . $this->table . " SET 
                  application_name = :application_name, 
                  company = :company,
                  application_description = :application_description, 
                  duration = :duration, 
                  category = :category, 
                  slots = :slots, 
                  deadline = :deadline
                  WHERE id = :id AND reviewer_id = :reviewer_id";

        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':reviewer_id', $this->reviewer_id);
        $stmt->bindParam(':application_name', $this->application_name);
        $stmt->bindParam(':company', $this->company);
        $stmt->bindParam(':application_description', $this->application_description);
        $stmt->bindParam(':duration', $this->duration);
        $stmt->bindParam(':category', $this->category);
        $stmt->bindParam(':slots', $this->slots);
        $stmt->bindParam(':deadline', $this->deadline);

        if ($stmt->execute()) {
            return ['status' => 'success', 'message' => 'Scholarship application updated successfully.'];
        }
        return ['status' => 'error', 'message' => 'Failed to update scholarship application.'];
    }

    private function uploadFile($file) {
        $targetDir = "documents/";
        $fileName = str_replace(' ', '_', basename($file["name"]));
        $uniqueFileName = uniqid() . '_' . $fileName;
        $targetFile = $targetDir . $uniqueFileName;
        $uploadOk = 1;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        if ($file["size"] > 5000000) { 
            return ['status' => 'error', 'message' => 'Sorry, your file is too large.'];
        }

        $allowedTypes = ['jpg', 'png', 'jpeg', 'gif', 'pdf', 'doc', 'docx'];
        if (!in_array($fileType, $allowedTypes)) {
            return ['status' => 'error', 'message' => 'Sorry, only JPG, JPEG, PNG, GIF, PDF, DOC, and DOCX files are allowed.'];
        }

        if ($uploadOk == 0) {
            return ['status' => 'error', 'message' => 'Sorry, your file was not uploaded.'];
        } else {
            if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                $baseUrl = 'https://active-fox-exactly.ngrok-free.app' . '/ScholarZone/';
                $fileUrl = $baseUrl . $targetFile;
                return ['status' => 'success', 'file_path' => $fileUrl];
            } else {
                return ['status' => 'error', 'message' => 'Sorry, there was an error uploading your file.'];
            }
        }
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " WHERE is_verified = 'yes' AND taken_slots != slots AND deadline >= CURDATE()";
        $stmt = $this->db->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getByReviewerId($reviewerId) {
        $query = "SELECT * FROM " . $this->table . " WHERE reviewer_id = :reviewer_id AND is_verified = 'yes'";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':reviewer_id', $reviewerId);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id AND reviewer_id = :reviewer_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->bindParam(':reviewer_id', $this->reviewer_id);

        return $stmt->execute();
    }

    public function searchApplications($keyword) {
        $query = "SELECT * FROM scholarship_applications 
                    WHERE (application_name LIKE :keyword 
                        OR company LIKE :keyword 
                        OR application_description LIKE :keyword 
                        OR category LIKE :keyword)
                    AND is_verified = 'yes'
                    AND taken_slots < slots
                    AND deadline >= CURDATE()";
        
        $stmt = $this->db->prepare($query);
        $searchTerm = "%$keyword%";
        $stmt->bindParam(':keyword', $searchTerm, PDO::PARAM_STR);
        $stmt->execute();
    
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }    

    private function sendFCMNotificationToAdmin($message) {
        $fcm_token = "ejNOUTMipntu7rG4AT6Pxx:APA91bHt3UnxszyfZ6E9b2KuYi_A6N81GbyzoSJCbXskjTe9et1IB3y01pKWAypXX_DbKMaAKT2AiI8ZyQDOXmh46B9_FPiwpH0TGsif37iaMMt4sjmnQZc";

        if (empty($fcm_token)) {
            return "Error: FCM token is missing.";
        }

        $accessToken = generateAccessToken();

        if (!$accessToken) {
            return "Error: Failed to generate access token.";
        }

        $url = "https://fcm.googleapis.com/v1/projects/scholarzone-d300c/messages:send";
        
        $headers = [
            "Authorization: Bearer " . $accessToken,
            "Content-Type: application/json"
        ];

        $notification = [
            "message" => [
                "token" => $fcm_token,
                "notification" => [
                    "title" => "New Scholarship Application",
                    "body" => $message
                ],
                "data" => [
                    "reviewer_id" => (string) $this->id,
                    "status" => "pending"
                ]
            ]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return "cURL Error: " . $curlError;
        }

        $this->storeNotification("New Scholarship Application", $message);

        return "HTTP Code: $httpCode\nResponse: $response";
    }

    private function storeNotification($title, $body) {
        $query = "INSERT INTO admin_notifications (title, body) VALUES (:title, :body)";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(":title", $title, PDO::PARAM_STR);
        $stmt->bindValue(":body", $body, PDO::PARAM_STR);
        $stmt->execute();
    }
}

?>